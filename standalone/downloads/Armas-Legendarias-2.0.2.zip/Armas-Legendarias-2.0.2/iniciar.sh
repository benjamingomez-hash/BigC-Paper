#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [ ! -f paper.jar ]; then
    echo 'Descarga Paper 26.2 y guardalo aqui con el nombre paper.jar.'
    exit 1
fi
java -Xms1G -Xmx2G -jar paper.jar --nogui
