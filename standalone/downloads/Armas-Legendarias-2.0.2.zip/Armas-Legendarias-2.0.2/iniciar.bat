@echo off
cd /d "%~dp0"
if not exist paper.jar (
    echo Descarga Paper 26.2 y guardalo aqui con el nombre paper.jar.
    pause
    exit /b 1
)
java -Xms1G -Xmx2G -jar paper.jar --nogui
pause
